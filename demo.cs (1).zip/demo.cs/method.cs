﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace democ_
{
    internal class method
    {
        public void mymethode(string name)
        {
            Console.WriteLine($"Welcome {name} ");
        }
    }
}
