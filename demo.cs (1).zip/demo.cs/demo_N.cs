﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch_1_c__demo
{
    internal class demo_N
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("hello world");
        }
    }
}
