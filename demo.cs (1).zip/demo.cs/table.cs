﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace level2_c_
//{
//    internal class table
//    {
//        public class vaithi
//        {
//            public void Main
//            {
//                Console.Wrieline("enter a number:");


//            }
//    }
//        {
//          Console.Wrieline("enter a number:");

                
//        }

//    }
//}
